/* After Hours with Anish Naik: site behaviour (routing, Goa clock, episodes, forms) */
(function(){
  // Set this to a form endpoint (Formspree, Getform, your backend) once the inbox is ready.
  var FORM_ENDPOINT = "";

  var views = {show:"view-show", episodes:"view-show", host:"view-host", contact:"view-contact", guest:"view-contact"};
  var nav = document.getElementById("nav");
  var menuBtn = document.getElementById("menuBtn");
  var lastId = null;

  function route(){
    var h = (location.hash || "").replace("#","");
    if(!views[h]) h = "show";
    var id = views[h];
    ["view-show","view-host","view-contact"].forEach(function(v){ document.getElementById(v).hidden = (v!==id); });
    nav.querySelectorAll("a").forEach(function(a){
      if(a.dataset.view===h) a.setAttribute("aria-current","page"); else a.removeAttribute("aria-current");
    });
    if(id==="view-contact") setTab(h==="contact" ? "contact" : "guest");
    if(h==="episodes") requestAnimationFrame(function(){ document.getElementById("episodes").scrollIntoView(); });
    else if(lastId!==null && lastId!==id) window.scrollTo(0,0);
    else if(h==="show" && lastId!==null) window.scrollTo(0,0);
    lastId = id;
    setMenu(false);
  }

  // ---------- episodes: real thumbnails and inline play when the site runs on its own domain ----------
  var topLevel = (function(){ try{ return window.top === window.self; }catch(e){ return false; } })();
  if(topLevel){
    document.querySelectorAll(".thumb[data-id]").forEach(function(t){
      var id = t.dataset.id;
      var img = document.createElement("img");
      img.className = "yt"; img.alt = ""; img.loading = "lazy";
      img.onload = function(){ if(img.naturalWidth > 200) t.classList.add("has-img"); };
      img.src = "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg";
      t.insertBefore(img, t.firstChild);
      t.addEventListener("click", function(e){
        e.preventDefault();
        var w = document.createElement("div");
        w.className = "thumb playing";
        var f = document.createElement("iframe");
        f.src = "https://www.youtube-nocookie.com/embed/" + id + "?autoplay=1&rel=0";
        f.title = t.getAttribute("aria-label") || "After Hours episode";
        f.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
        f.setAttribute("allowfullscreen", "");
        w.appendChild(f);
        t.replaceWith(w);
      });
    });
  }
  function setTab(t){
    var g = t==="guest";
    document.getElementById("panel-guest").hidden = !g;
    document.getElementById("panel-contact").hidden = g;
    document.getElementById("tab-guest").setAttribute("aria-selected", g);
    document.getElementById("tab-contact").setAttribute("aria-selected", !g);
    document.getElementById("noteGuest").hidden = !g;
    document.getElementById("noteGuest2").hidden = !g;
    document.getElementById("noteContact").hidden = g;
  }
  window.addEventListener("hashchange", route);
  function setMenu(o){
    nav.classList.toggle("open", o);
    menuBtn.setAttribute("aria-expanded", o);
    menuBtn.textContent = o ? "CLOSE" : "MENU";
    document.body.classList.toggle("menu-open", o);
  }
  menuBtn.addEventListener("click", function(){ setMenu(!nav.classList.contains("open")); });
  window.addEventListener("resize", function(){ if(window.innerWidth > 720) setMenu(false); });
  document.querySelectorAll('[data-reason="nxt"]').forEach(function(a){
    a.addEventListener("click", function(){ var s=document.getElementById("c_reason"); if(!s.value){ s.value="NXT Take: personal branding"; save(s); } });
  });

  // ---------- Goa clock ----------
  function goaNow(){
    var parts = new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",hour:"2-digit",minute:"2-digit",hour12:false}).formatToParts(new Date());
    var h = +parts.find(function(p){return p.type==="hour"}).value % 24;
    var m = +parts.find(function(p){return p.type==="minute"}).value;
    return {h:h,m:m};
  }
  function fmt(h,m){ var ap = h>=12?"PM":"AM"; var hh = h%12||12; return hh+":"+(m<10?"0":"")+m+" "+ap; }
  function tick(){
    var t = goaNow();
    var after = (t.h>=22 || t.h<4);
    document.getElementById("clock").textContent = "GOA " + fmt(t.h,t.m) + (after ? " · AFTER HOURS" : "");
    document.getElementById("dot").classList.toggle("live", after);
    document.getElementById("hostClock").textContent = "Goa " + fmt(t.h,t.m);
    var d = document.getElementById("doors");
    if(after){ d.textContent = "Goa · The room is open"; }
    else {
      var mins = (22*60) - (t.h*60+t.m); if(mins<0) mins += 1440;
      d.textContent = "Goa · Doors in " + Math.floor(mins/60) + "h " + (mins%60) + "m";
    }
  }
  tick(); setInterval(tick, 20000);

  // ---------- drafts ----------
  var store = { get:function(k){ try{return localStorage.getItem(k)}catch(e){return null} },
                set:function(k,v){ try{localStorage.setItem(k,v)}catch(e){} },
                del:function(k){ try{localStorage.removeItem(k)}catch(e){} } };
  function save(el){ store.set("ah_"+el.id, el.type==="checkbox" ? (el.checked?"1":"") : el.value); }
  document.querySelectorAll("form input, form select, form textarea").forEach(function(el){
    var v = store.get("ah_"+el.id);
    if(v!==null){ if(el.type==="checkbox") el.checked = v==="1"; else el.value = v; }
    el.addEventListener("input", function(){ save(el); var f=el.closest(".field"); if(f) f.classList.remove("invalid"); var e=f&&f.querySelector(".err"); if(e) e.textContent=""; });
    el.addEventListener("change", function(){ save(el); });
  });

  // ---------- forms ----------
  function validate(form){
    var ok = true, first = null;
    form.querySelectorAll("[required]").forEach(function(el){
      var f = el.closest(".field"), err = f.querySelector(".err"), msg = "";
      var v = el.value.trim();
      if(!v) msg = el.tagName==="SELECT" ? "Choose one option." : "This one’s needed.";
      else if(el.type==="email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) msg = "That email doesn’t look right. Check for a typo.";
      f.classList.toggle("invalid", !!msg); if(err) err.textContent = msg;
      if(msg){ ok=false; if(!first) first=el; }
    });
    if(first) first.focus();
    return ok;
  }
  function collect(form){
    var lines = [form.dataset.kind.toUpperCase() + " · After Hours with Anish Naik", ""];
    var data = {type: form.dataset.kind};
    form.querySelectorAll("input:not([type=checkbox]), select, textarea").forEach(function(el){
      var v = el.value.trim(); if(!v) return;
      data[el.name] = v; lines.push(el.name + ": " + v);
    });
    form.querySelectorAll(".chips").forEach(function(g){
      var picked = Array.prototype.map.call(g.querySelectorAll("input:checked"), function(c){return c.value});
      if(picked.length){ data[g.dataset.name] = picked.join(", "); lines.push(g.dataset.name + ": " + picked.join(", ")); }
    });
    return {data:data, text:lines.join("\n")};
  }
  function clearDraft(form){
    form.querySelectorAll("input, select, textarea").forEach(function(el){ store.del("ah_"+el.id); });
  }
  function showDone(form, doneEl, payload, sent){
    var first = (payload.data.Name || "").split(" ")[0] || "friend";
    doneEl.innerHTML = "";
    var h = document.createElement("h3"); h.textContent = "Thank you, " + first + ".";
    var p = document.createElement("p"); p.className = "muted";
    p.textContent = sent
      ? "Your note is in. Anish will read it and reply to the email you gave."
      : "Your note is ready below. Copy it and send it to Anish on YouTube while the inbox is being connected.";
    var pre = document.createElement("pre"); pre.id = form.id + "Text"; pre.textContent = payload.text;
    var row = document.createElement("div"); row.className = "row";
    var copy = document.createElement("button"); copy.type="button"; copy.className="btn solid"; copy.textContent="Copy note";
    var msg = document.createElement("span"); msg.className="copied"; msg.setAttribute("role","status");
    copy.addEventListener("click", function(){
      var done = function(){ msg.textContent = "Copied"; setTimeout(function(){msg.textContent=""},2000); };
      var fallback = function(){ var r=document.createRange(); r.selectNodeContents(pre); var s=getSelection(); s.removeAllRanges(); s.addRange(r); msg.textContent="Selected. Press copy."; };
      try{ navigator.clipboard.writeText(payload.text).then(done, fallback); }catch(e){ fallback(); }
    });
    var yt = document.createElement("a"); yt.className="btn"; yt.href="https://www.youtube.com/@AfterHourswithAnishNaik"; yt.target="_blank"; yt.rel="noopener"; yt.textContent="Open the channel";
    var edit = document.createElement("button"); edit.type="button"; edit.className="btn"; edit.textContent="Start a new one";
    edit.addEventListener("click", function(){ form.reset(); doneEl.hidden = true; form.hidden = false; });
    row.appendChild(copy); if(!sent) row.appendChild(yt); row.appendChild(edit); row.appendChild(msg);
    doneEl.appendChild(h); doneEl.appendChild(p); if(!sent) doneEl.appendChild(pre); doneEl.appendChild(row);
    form.hidden = true; doneEl.hidden = false;
    doneEl.scrollIntoView({behavior:"smooth", block:"start"});
  }
  [["guestForm","guestDone"],["contactForm","contactDone"]].forEach(function(pair){
    var form = document.getElementById(pair[0]), doneEl = document.getElementById(pair[1]);
    form.addEventListener("submit", function(e){
      e.preventDefault();
      if(!validate(form)) return;
      var payload = collect(form);
      var btn = form.querySelector("[type=submit]");
      if(FORM_ENDPOINT){
        btn.disabled = true; btn.textContent = "Sending...";
        fetch(FORM_ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify(payload.data)})
          .then(function(r){ if(!r.ok) throw 0; clearDraft(form); showDone(form, doneEl, payload, true); })
          .catch(function(){ showDone(form, doneEl, payload, false); })
          .then(function(){ btn.disabled=false; btn.textContent = form.id==="guestForm" ? "Send application" : "Send message"; });
      } else {
        clearDraft(form); showDone(form, doneEl, payload, false);
      }
    });
  });

  route();
})();
