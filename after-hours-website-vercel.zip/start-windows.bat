@echo off
title After Hours with Anish Naik - local website
cd /d "%~dp0"
set PORT=3000

echo.
echo   AFTER HOURS with Anish Naik
echo   Starting the website on http://localhost:%PORT%
echo   Keep this window open. Close it to stop the site.
echo.

node --version >nul 2>nul
if not errorlevel 1 goto USE_NODE

python --version >nul 2>nul
if not errorlevel 1 goto USE_PYTHON

py --version >nul 2>nul
if not errorlevel 1 goto USE_PY

echo   Could not find Node.js or Python on this computer.
echo   Install one of these, then double-click this file again:
echo     Node.js LTS : https://nodejs.org
echo     Python      : https://www.python.org/downloads/  - tick "Add Python to PATH"
echo.
pause
exit /b 1

:USE_NODE
echo   Using Node.js
start "" cmd /c "timeout /t 3 >nul & start http://localhost:%PORT%"
call npx --yes serve@14.2.4 . -l %PORT%
goto END

:USE_PYTHON
echo   Using Python
start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%"
python -m http.server %PORT%
goto END

:USE_PY
echo   Using Python
start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%"
py -m http.server %PORT%
goto END

:END
pause
