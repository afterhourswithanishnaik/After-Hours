# After Hours with Anish Naik: Website

The official website for **After Hours with Anish Naik**, a late-night conversational podcast from Goa.

It's a plain static site: HTML, CSS and JavaScript. No framework, no build step. Everything it needs (fonts, images, icons) is inside this folder, so it runs offline.

---

## Pages

The site is one file (`index.html`) with three pages, switched by the link after the `#` in the address bar:

| Address | Page |
| --- | --- |
| `#show` (default) | The Show: hero, episodes, what "after hours" means, your host |
| `#episodes` | Jumps straight to the episodes section |
| `#host` | The Host: bio, hosting style, ventures (After Hours, NXT Take) |
| `#guest` | Be on the podcast: guest application form |
| `#contact` | Get in touch: enquiry form |

---

## Folder structure

```
after-hours-website/
├── index.html              All page markup
├── css/
│   ├── fonts.css           Local font definitions
│   └── style.css           All site styles
├── js/
│   └── main.js             Page switching, Goa clock, episode player, forms
├── assets/
│   ├── images/
│   │   ├── logo.webp           Podcast logo (header and footer)
│   │   ├── anish.webp          Host portrait
│   │   ├── favicon.ico         Browser tab icon
│   │   ├── favicon-32.png
│   │   └── apple-touch-icon.png
│   └── fonts/              Bodoni Moda, Hanken Grotesk, IBM Plex Mono (woff2)
├── 404.html                Custom "page not found" page
├── vercel.json             Vercel settings (static site, caching)
├── start-windows.bat       Double-click to run on Windows
├── .gitignore
└── README.md
```

---

## Run it on Windows

You need a small local server so the YouTube players work. (Opening `index.html` by double-clicking mostly works, but YouTube blocks its video player on pages opened straight from a file.)

### Option 1: Double-click (easiest)

1. Unzip the folder anywhere, for example your Desktop.
2. Double-click **`start-windows.bat`**.
3. Your browser opens **http://localhost:3000**.
4. To stop the site, close the black command window.

The launcher uses Node.js if you have it, otherwise Python. If you have neither, it tells you what to install.

### Option 2: Node.js

1. Install Node.js (LTS) from https://nodejs.org
2. Open the folder, click the address bar in File Explorer, type `cmd` and press Enter.
3. Run:

   ```
   npx serve . -l 3000
   ```

4. Open **http://localhost:3000**

### Option 3: Python

1. Install Python from https://www.python.org/downloads/ and tick **"Add Python to PATH"** during setup.
2. Open a command window in the folder (as above) and run:

   ```
   python -m http.server 3000
   ```

3. Open **http://localhost:3000**

### Option 4: VS Code

Install the **Live Server** extension, open the folder in VS Code, right-click `index.html` and choose **Open with Live Server**.

---

## Connect the forms (important)

The "Be on the podcast" and "Get in touch" forms validate everything and save drafts in the visitor's browser. To have submissions **land in your email**, connect a form service. The free option is Formspree:

1. Sign up at https://formspree.io and create a new form with your email.
2. Copy the form endpoint, which looks like `https://formspree.io/f/abcdwxyz`.
3. Open `js/main.js` and paste it here, near the top:

   ```js
   var FORM_ENDPOINT = "https://formspree.io/f/abcdwxyz";
   ```

4. Save, refresh, and send a test submission.

Both forms post to the same endpoint. Each submission includes a `type` field ("Guest application" or "Enquiry") so you can tell them apart in your inbox.

Until an endpoint is set, a visitor who submits sees their details as a note they can copy and send manually.

---

## Episodes

Episodes are in `index.html` inside the section with `id="episodes"`. When the site runs on a server (local or live):

- Each card loads its real YouTube thumbnail.
- Clicking a card plays the episode right on the page.

**To add a new episode:**

1. Copy one `<article class="ep">...</article>` block in the episode grid.
2. Change the YouTube video ID in **`data-id`** and in every `watch?v=` link. The ID is the part after `v=` in a YouTube link, for example `VKcX1ma2hdA`.
3. Update the episode code, date, guest name, title and one-line summary.
4. To make it the featured "Latest" episode, update the block inside `<div class="feature">` and move the previous latest into the grid.

---

## Customise

- **Colours and fonts:** the variables at the top of `css/style.css` (`--ink`, `--ice`, `--champ`, and so on).
- **Text:** edit `index.html` directly.
- **Photo or logo:** replace the files in `assets/images/` with the same names, or update the `src` paths.
- **"After hours" clock:** the header shows Goa time and switches to "After Hours" between 10 PM and 4 AM. The hours are set in `tick()` in `js/main.js`.

---

## Deploy on Vercel (from a Git repo)

**The most important rule:** `index.html` must be at the **top level of the repository**, not inside a subfolder. If it sits in a subfolder, Vercel serves an empty root and shows `404: NOT_FOUND`.

Your repo should look like this when you open it on GitHub:

```
your-repo/
├── index.html
├── 404.html
├── vercel.json
├── css/
├── js/
├── assets/
└── README.md
```

### Steps

1. Create a new, empty repository on GitHub.
2. Unzip this file. Open the unzipped folder (the one that contains `index.html`) and run, in a terminal:

   ```
   git init
   git add .
   git commit -m "After Hours website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```

   Or upload the files on GitHub with **Add file > Upload files**. Drag in the **contents** of the folder, not the folder itself.

3. On https://vercel.com click **Add New > Project** and import the repo.
4. Use these settings:

   | Setting | Value |
   | --- | --- |
   | Framework Preset | **Other** |
   | Root Directory | `./` (leave as is) |
   | Build Command | leave empty / off |
   | Output Directory | leave empty / off |
   | Install Command | leave empty / off |

5. Click **Deploy**. Every push to `main` redeploys automatically.

### Still seeing 404?

- **Files are in a subfolder in the repo:** either move them to the top level, or in Vercel go to **Project > Settings > Build and Deployment > Root Directory** and set it to that folder's name, then redeploy.
- **Old settings stuck:** in **Settings > Build and Deployment**, set Framework Preset to **Other** and turn off any Build Command or Output Directory overrides, then redeploy from the **Deployments** tab.
- **File name case:** Vercel is case-sensitive. Keep the file and folder names exactly as they are in this zip.

### Custom domain

In Vercel open **Project > Settings > Domains**, add your domain and follow the DNS records it shows you.

## Other hosts

It's a static site, so any static host works too:

- **Netlify:** drag and drop the folder at https://app.netlify.com/drop
- **GitHub Pages:** push to a repository and turn on Pages in its settings
- **cPanel / Hostinger / GoDaddy:** upload the contents into `public_html`

---

## Credits

- Fonts: Bodoni Moda, Hanken Grotesk and IBM Plex Mono, all under the SIL Open Font License.
- Podcast: https://www.youtube.com/@AfterHourswithAnishNaik
